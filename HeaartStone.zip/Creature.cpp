#pragma once
#include "stdafx.h"
#include "Creature.h"
#include "BattleField.h"

Creature::Creature(
	BattleField * field,
	int cost, string name,
	int power, int shield,
	int attcount, 
	bool agro, bool holy)
	:Card(cost, name,field),
	nPower(power), nShield(shield),
	nPowerOrigin(power), nShieldOrigin(shield),
	nAttackCount(attcount), nAttackCountOrigin(attcount),	
	isAgro(agro),isHolyShiled(holy)
{}

void Creature::Use()
{
	int turn = battleFieldOfCard->nPlayerTurn % 2;

	if (battleFieldOfCard->cost[turn] >= nCost)
	{
		battleFieldOfCard->cost[turn] -= nCost; // �ڽ�Ʈ �Ҹ�
		cout << "=================================" << endl;
		cout << "==" << strName << "��(��) ��ȯ�մϴ�==" << endl;
		cout << "=================================" << endl;
		FirstSkill();
		battleFieldOfCard->cardsOfField[turn].push_back(new Creature(*this));
		isDelete = true;
	}
	else
	{
		cout << "=================================" << endl;
		cout << "==������ �ִ� �ڽ�Ʈ�� �����մϴ�.==" << endl;
		cout << "=================================" << endl;
	}
	Sleep(1000);
}



void Creature::AttackSkill(Card * target)
{
	return;
}

void Creature::FirstSkill(Card * target)
{
	return;
}

void Creature::detail()
{
	cout << "�̸� : " << strName << endl
		<< "�ڽ�Ʈ : " << nCost << endl
		<< "�Ŀ� : " << nPower << endl
		<< "ü�� : " << nShield << endl;
	cout << "��׷� : ";
	if (isAgro) cout << "����" << endl;
	else cout << "����" << endl;
	cout << "õ���� ��ȣ�� : ";
	if (isHolyShiled) cout << "����" << endl;
	else cout << "����" << endl;
}







