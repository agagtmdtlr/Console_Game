#pragma once
#include <iostream>
#include <string>
#include <ctime>
#include <Windows.h>
#include <vector>

using namespace std;

enum class E_ACTION
{
	DRAW,HAND,FIELD,GG
};

enum class E_FIELD_ACTION
{
	ATTACK,
};
