#pragma once
class GameManage
{
public:
	void PlayGaming();
};



