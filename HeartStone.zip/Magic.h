#pragma once
#include "Card.h"
class Magic :
	public Card
{
};

