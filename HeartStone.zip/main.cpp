#pragma once
#include "stdafx.h"
#include "GameManage.h"

int main()
{
	GameManage GM;
	GM.PlayGaming();
}