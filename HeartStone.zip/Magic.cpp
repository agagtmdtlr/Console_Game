#pragma once
#include "stdafx.h"
#include "Magic.h"
